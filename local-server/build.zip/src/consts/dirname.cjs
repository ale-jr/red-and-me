const path = require("path");
module.exports = () => {
  return path.join(__dirname, "..");
};
