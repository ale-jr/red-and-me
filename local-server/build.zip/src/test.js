import { tabletConnection, KEYS } from "./services/tabletConnection.js";

tabletConnection.sendKey(KEYS.playPause);
