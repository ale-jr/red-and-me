export const styleTags = `
<link rel='stylesheet' type='text/css' media='screen' href='css/fonts.css'>
    <link rel='stylesheet' type='text/css' media='screen' href='css/common.css'>
    <link rel='stylesheet' type='text/css' media='screen' href='css/dash.css'>
    <link href="assets/font-awesome/css/fontawesome.css" rel="stylesheet">
    <link href="assets/font-awesome/css/brands.css" rel="stylesheet">
    <link href="assets/font-awesome/css/solid.css" rel="stylesheet">
`;
