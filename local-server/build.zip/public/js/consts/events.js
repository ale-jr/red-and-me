export const WS_MESSAGE = "@@websocket-message";

export const WS_SEND_MESSAGE = "@@websocket-send-message";
