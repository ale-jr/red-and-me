export const DEFAULT_CAMERA_SETTINGS = {
  height: 480,
  width: 720,
  scale: 1,
  x: 0,
  y: 0,
  rotate: 0,
};
