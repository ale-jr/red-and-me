export const CLOUD_SERVER_URL = "https://red-and-me.alejr.dev/";

//export const LOCAL_SERVER_WS_URL = "ws://localhost:3000"
export const LOCAL_SERVER_WS_URL = "ws://192.168.78.100:3000"
export const LOCAL_SERVER_HTTP_URL = 'http://192.168.78.100:3000'